﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pacman
{
	public partial class Form1 : Form
	{
		static Timer timer = new Timer();
		static Random r = new Random();

		public Form1()
		{
			InitializeComponent();
			timer.Interval = 500;
			timer.Tick += new EventHandler(TimerCallback);
		}

		// pri kazdom tiknuti timeru pohne duchov a premaluje plochu
		private void TimerCallback(object sender, EventArgs e)
		{
			Game.NextMove();
			this.Invalidate();
			return;
		}

		// premaluje plochu na aktualny stav
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics g = e.Graphics;
			Game.ColorMap(g);
			base.OnPaint(e);
		}

		// pri stlaceni klavesov pohne pacmana do urceneho smeru
		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			Invalidate();
			if (keyData == Keys.Up || keyData == Keys.W)
			{
				Player.MoveUp();
				return true;
			}
			else if (keyData == Keys.Right || keyData == Keys.D)
			{
				Player.MoveRight();
				return true;
			}
			else if (keyData == Keys.Left || keyData == Keys.A)
			{
				Player.MoveLeft();
				return true;
			}
			else if (keyData == Keys.Down || keyData == Keys.S)
			{
				Player.MoveDown();
				return true;
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}

		// zobrazi okno so zadanou spravou
		public static class Dialog
		{
			public static void DisplayDialog(string text, string caption, int size)
			{
				Form dialog = new Form()
				{
					Width = 500,
					Height = 100 + size * 20,
					FormBorderStyle = FormBorderStyle.FixedDialog,
					Text = caption,
					StartPosition = FormStartPosition.CenterScreen
				};
				Label message = new Label() { Left = 50, Top = 20, Width = 400, Height = 20 + size * 20, Text = text };
				Button confirmButton = new Button() { Text = "OK", Left = 350, Width = 100, Top = 20 + size * 20, DialogResult = DialogResult.OK };
				confirmButton.Click += (sender, e) => { dialog.Close(); };
				dialog.Controls.Add(confirmButton);
				dialog.Controls.Add(message);
				dialog.AcceptButton = confirmButton;

				dialog.ShowDialog();
			}
		}

		// orientacia v priestore
		class SvetoveStrany
		{
			// posunie suradnice v danom (globalnom) smere
			public static void Smer(char direction, ref int res_x, ref int res_y)
			{
				switch (direction)
				{
					case 'u': res_x--; break;
					case 'd': res_x++; break;
					case 'r': res_y++; break;
					case 'l': res_y--; break;
				}
			}

			// vrati relativny smer napravo
			public static char OtocVpravo(char direction)
			{
				switch (direction)
				{
					case 'r': return (char)'d';
					case 'l': return (char)'u';
					case 'u': return (char)'r';
					case 'd': return (char)'l';
					default: return '0';
				}
			}

			// vrati relativny smer nalavo
			public static char OtocVlavo(char direction)
			{
				switch (direction)
				{
					case 'r': return (char)'u';
					case 'l': return (char)'d';
					case 'u': return (char)'l';
					case 'd': return (char)'r';
					default: return '0';
				}
			}
		}

		// praca s duchmi
		class Ghost
		{
			int id;
			int x, y;
			char direction;

			// inicializacia - id, suradnice a orientacia
			public Ghost(int id, int x, int y, char direction)
			{
				this.id = id;
				SetPosition(x, y);
				SetDirection(direction);
			}

			// podla pravidiel pohybu ducha zisti, co urobi dalsie
			public void NajdiDalsiTah(ref int next_x, ref int next_y)
			{
				int rand = r.Next(3);
				int new_x = x, new_y = y;
				bool canGo = true;

				// najskor sa pokusi pohnut do nahodneho smeru (aby sa netocil do kruhu)
				if (rand == 0)
				{
					SvetoveStrany.Smer(SvetoveStrany.OtocVpravo(GetDirection()), ref new_x, ref new_y);
					if (Game.IsAvailable(new_x, new_y) && !Game.IsGhostHere(new_x, new_y))
					{
						SetDirection(SvetoveStrany.OtocVpravo(GetDirection()));
						SetPosition(new_x, new_y);
					}
					else
					{ canGo = false; }
				}
				else if (rand == 1)
				{
					new_x = x; new_y = y;
					SvetoveStrany.Smer(SvetoveStrany.OtocVlavo(GetDirection()), ref new_x, ref new_y);
					if (Game.IsAvailable(new_x, new_y) && !Game.IsGhostHere(new_x, new_y))
					{
						SetDirection(SvetoveStrany.OtocVlavo(GetDirection()));
						SetPosition(new_x, new_y);
					}
					else
					{
						canGo = false;
					}
				}
				else if (rand == 2)
				{
					new_x = x; new_y = y;
					SvetoveStrany.Smer(GetDirection(), ref new_x, ref new_y);
					if (Game.IsAvailable(new_x, new_y) && !Game.IsGhostHere(new_x, new_y))
					{
						SetPosition(new_x, new_y);
					}
					else
					{
						canGo = false;
					}
				}

				// ak sa mu to nepodari, ide na to deterministicky - doprava -> rovno -> dolava
				if (!canGo)
				{
					// najskor sa pokusi otocit doprava
					new_x = x; new_y = y;
					SvetoveStrany.Smer(SvetoveStrany.OtocVpravo(GetDirection()), ref new_x, ref new_y);
					if (Game.IsAvailable(new_x, new_y) && !Game.IsGhostHere(new_x, new_y))
					{
						SetDirection(SvetoveStrany.OtocVpravo(GetDirection()));
						SetPosition(new_x, new_y);
					}
					else
					{
						// ak jej to nejde, skusi ist dopredu
						new_x = x; new_y = y;               // treba vratit suradnice na skutocnu poziciu ducha
						SvetoveStrany.Smer(GetDirection(), ref new_x, ref new_y);
						if (Game.IsAvailable(new_x, new_y) && !Game.IsGhostHere(new_x, new_y))
						{
							SetPosition(new_x, new_y);
						}
						else
						{
							// a ak sa nevie pohnut rovno, otoci sa dolava
							SetDirection(SvetoveStrany.OtocVlavo(GetDirection()));
						}
					}
				}
				
				next_x = x; next_y = y;
			}

			// vrati aktualny smer ducha
			public char GetDirection()
			{
				return direction;
			}

			// nastavi smer ducha - pocita aj s formatom zo vstupu
			public void SetDirection(char direction)
			{
				switch (direction)
				{
					case '>': case 'r': this.direction = 'r'; break;
					case '<': case 'l': this.direction = 'l'; break;
					case '^': case 'u': this.direction = 'u'; break;
					case 'v': case 'd': this.direction = 'd'; break;
				}
			}

			// vrati aktualne suradnice ducha
			public void GetPosition(ref int x, ref int y)
			{
				x = this.x;
				y = this.y;
			}

			// posunie ducha
			public void SetPosition(int x, int y)
			{
				this.x = x;
				this.y = y;
			}

			// vrati id ducha
			public int GetId()
			{
				return id;
			}
		}

		// ovladanie pacmana
		class Player
		{
			static int x = 20, y = 9; // zaciatocna pozicia

			// pohne sa hore
			public static void MoveUp()
			{
				int res_x = x, res_y = y;
				SvetoveStrany.Smer('u', ref res_x, ref res_y);
				if (Game.IsAvailable(res_x, res_y))
				{
					Game.MovePlayer(res_x, res_y);
				}
			}

			// pohne sa dole
			public static void MoveDown()
			{
				int res_x = x, res_y = y;
				SvetoveStrany.Smer('d', ref res_x, ref res_y);
				if (Game.IsAvailable(res_x, res_y))
				{
					Game.MovePlayer(res_x, res_y);
				}
			}

			// pohne sa doprava
			public static void MoveRight()
			{
				int res_x = x, res_y = y;
				SvetoveStrany.Smer('r', ref res_x, ref res_y);
				if (Game.IsAvailable(res_x, res_y))
				{
					Game.MovePlayer(res_x, res_y);
				}
			}
			
			// pohne sa dolava
			public static void MoveLeft()
			{
				int res_x = x, res_y = y;
				SvetoveStrany.Smer('l', ref res_x, ref res_y);
				if (Game.IsAvailable(res_x, res_y))
				{
					Game.MovePlayer(res_x, res_y);
				}
			}

			// vrati suradnice, kde sa hrac prave nachadza
			public static void GetPosition(ref int cur_x, ref int cur_y)
			{
				cur_x = x;
				cur_y = y;
			}

			// nastavi novu poziciu
			public static void SetPosition(int new_x, int new_y)
			{
				x = new_x;
				y = new_y;
			}
		}

		// ovladanie hry
		class Game
		{
			static int height = 22, width = 19;
			static int undiscoveredSquares = 0;		// kolko policok uz hrac navstivil
			static int[,] map = new int[height * 2, width * 2];				// mapa volnych a nepristupnych policok
			static int[,] currentState = new int[height * 2, width * 2];	// aktualny stav vratane duchov a hraca
			static Ghost[] ghosts = new Ghost[3];

			// nastavi zakladne sucasti hry
			public static void Initialize(string file)
			{
				LoadMap(file);
				currentState = (int[,])map.Clone();
				currentState[20, 9] = 5;
				map[20, 9] = -1;
				--undiscoveredSquares;	// na jednom stvorceku uz hrac stoji
				LoadGhosts();

				string pravidla = "Pravidlá hry:\nHráte za žltý štvorček. Pohybujete sa šípkami alebo klávesami WASD.\n" +
								  "Môžete sa pohybovať po čiernych štvorčekoch. Prejdené políčko sa vyfarbí nasivo. " +
								  "Vyhráte, ak prejdete všetky políčka. Prehráte, ak vás zje duch (to, čo sa hýbe a nie je žlté).\n" +
								  "Veľa šťastia! Hru začnete kliknutím na OK.";
				Dialog.DisplayDialog(pravidla, "Vitajte!", 5);
				timer.Enabled = true;
			}

			// nacita mapu zo suboru a zisti, kolko je volnych policok, to ulozi do undiscoveredSquares
			public static void LoadMap(string file)
			{
				System.IO.StreamReader r = new System.IO.StreamReader(file);
				for (int i = 0; i < height; ++i)
				{
					string line = r.ReadLine();
					for (int j = 0; j < width; ++j)
					{
						switch (line[j])
						{
							case 'x':
								map[i, j] = 1;
								map[i + 1, j] = 1;
								map[i, j + 1] = 1;
								map[i + 1, j + 1] = 1;
								break;
							case '.':
								map[i, j] = 0;
								map[i + 1, j] = 0;
								map[i, j + 1] = 0;
								map[i + 1, j + 1] = 0;
								++undiscoveredSquares;
								break;
						}
					}
				}
			}

			// vykresli mapu na plochu (aj s duchmi a hracom)
			public static void ColorMap(Graphics g)
			{
				SolidBrush brush = new SolidBrush(Color.Black);
				for (int i = 0; i < height; ++i)
				{
					for (int j = 0; j < width; ++j)
					{
						switch (currentState[i, j])
						{
							case -1: brush = new SolidBrush(Color.DimGray); break;
							case 0: brush = new SolidBrush(Color.Black); break;
							case 1: brush = new SolidBrush(Color.Blue); break;
							case 2: brush = new SolidBrush(Color.Cyan); break;
							case 3: brush = new SolidBrush(Color.DeepPink); break;
							case 4: brush = new SolidBrush(Color.Tomato); break;
							case 5: brush = new SolidBrush(Color.Yellow); break;
						}
						g.FillRectangle(brush, j * 20, i * 20, 20, 20);
					}

				}
			}

			// nastavi duchov na ich policka
			public static void LoadGhosts()
			{
				for (int i = 0; i < 3; ++i)
				{
					ghosts[i] = new Ghost(i + 2, 10, 8 + i, 'u');
					currentState[10, 8 + i] = i + 2;
				}
			}

			// zisti, ci sa na danom policku nachadza duch
			public static Boolean IsGhostHere(int x, int y)
			{
				Boolean result = false;
				foreach (Ghost g in ghosts)
				{
					int temp_x = -1, temp_y = -1;
					g.GetPosition(ref temp_x, ref temp_y);
					if (temp_x == x && temp_y == y) result = true;
				}
				return result;
			}

			// zisti, ci sa na danom policku nachadza hrac
			public static Boolean IsPlayerHere(int x, int y)
			{
				int player_x = 0, player_y = 0;
				Player.GetPosition(ref player_x, ref player_y);
				return (player_x == x && player_y == y);
			}

			// zisti, ci je pole volne (ak je tam duch alebo hrac, povazuje ho za volne)
			public static Boolean IsAvailable(int x, int y)
			{
				if (x >= height || x < 0 || y >= width || y < 0) return false;
				return (map[x, y] == 0 || map[x, y] == -1);
			}

			// pohne vsetkych duchov, ak nejaky vrazil do hraca, skonci hru
			public static void NextMove()
			{
				int next_x = 0, next_y = 0;
				int cur_x = 0, cur_y = 0;
				foreach (Ghost g in ghosts)
				{
					g.GetPosition(ref cur_x, ref cur_y);
					g.NajdiDalsiTah(ref next_x, ref next_y);
					currentState[cur_x, cur_y] = map[cur_x, cur_y];
					currentState[next_x, next_y] = g.GetId();
					if (IsPlayerHere(next_x, next_y))
					{
						EndGame(0);
					}
				}
			}

			// posunie hraca na zelane policko
			public static void MovePlayer(int x, int y)
			{
				int cur_x = 0, cur_y = 0;
				Player.GetPosition(ref cur_x, ref cur_y);
				currentState[cur_x, cur_y] = map[cur_x, cur_y];
				currentState[x, y] = 5;
				// ak prisiel niekam, kde este nebol, zmensime pocet neobjavenych stvorcekov
				if (map[x, y] == 0)
				{
					map[x, y] = -1;
					--undiscoveredSquares;
				}
				Player.SetPosition(x, y);
				// ak vrazil do ducha, prehral
				if (IsGhostHere(x, y)) { EndGame(0); }
				// ak uz presiel vsetky policka, vyhral
				if (undiscoveredSquares == 0) { EndGame(1); }
			}

			// vypise konecny vysledok hry
			public static void EndGame(int result)
			{
				timer.Stop();
				string message;
				if (result == 0)
				{
					message = "Prehrali ste :(";
				}
				else
				{
					message = "Vyhrali ste :)";
				}
				Dialog.DisplayDialog(message, "Koniec hry", 1);
			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			this.Width = 400;
			this.Height = 480;
			this.Text = "Low cost Pacman";
			this.BackColor = Color.Blue;
			Game.Initialize("mapa.txt");
		}
	}
}
